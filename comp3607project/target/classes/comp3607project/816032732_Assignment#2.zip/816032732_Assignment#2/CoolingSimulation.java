// 816032732 - Ethan Lee Chong

import java.util.ArrayList;

public class CoolingSimulation {
    private ArrayList<Room> Rooms;
    
    public CoolingSimulation() {
        this.Rooms = new ArrayList<Room>();
    }
    
    public ArrayList<Room> getRooms() {
        return Rooms;
    }
    
    public Room getRoom(int i) {
        if (i < 1 || i > 4) {
            return null;
        }
        return Rooms.get(i - 1);
    }
    
    public void createRooms() {
        Room Room1 = new Room(30);
        Room Room2 = new Room(35);
        Room Room3 = new Room(37);
        Room Room4 = new Room(25);
        Rooms.add(Room1);
        Rooms.add(Room2);
        Rooms.add(Room3);
        Rooms.add(Room4);
    }
    
    public void createDevices() {
        Room Room1 = getRoom(1);
        Device AC1 = new AC();
        Device CF1 = new CeilingFan();
        Device SF1 = new StandingFan();
        Device SF2 = new StandingFan();
        Device SF3 = new StandingFan();
        Room1.addDevice(AC1);
        Room1.addDevice(CF1);
        Room1.addDevice(SF1);
        Room1.addDevice(SF2);
        Room1.addDevice(SF3);
        
        Room Room2 = getRoom(2);
        Device AC2 = new AC();
        Device AC3 = new AC();
        Device CF2 = new CeilingFan();
        Device SF4 = new StandingFan();
        Device SF5 = new StandingFan();
        Device SF6 = new StandingFan();
        Device SF7 = new StandingFan();
        Room2.addDevice(AC2);
        Room2.addDevice(AC3);
        Room2.addDevice(CF2);
        Room2.addDevice(SF4);
        Room2.addDevice(SF5);
        Room2.addDevice(SF6);
        Room2.addDevice(SF7);
        
        
        Room Room3 = getRoom(3);
        Device AC4 = new AC();
        Room3.addDevice(AC4);
        Device CF3 = new CeilingFan();
        Device CF4 = new CeilingFan();
        Room3.addDevice(CF3);
        Room3.addDevice(CF4);
        Device SF8 = new StandingFan();
        Device SF9 = new StandingFan();
        Room3.addDevice(SF8);
        Room3.addDevice(SF9);
        
        Room Room4 = getRoom(4);
        Device AC5 = new AC();
        Device CF5 = new CeilingFan();
        Device SF10 = new StandingFan();
        Room4.addDevice(AC5);
        Room4.addDevice(CF5);
        Room4.addDevice(SF10);
    }
    
    public void swapPortableDevices(Room r1, Room r2) {
        ArrayList<Device> d = new ArrayList();
        for (int i = 0; i < r1.getDevices().size(); i++) {
            Device s = r1.getDevices().get(i);
            if (s instanceof PortableDevice && s.isOn() == false) {
                d.add(s);
            }
        }
        
       for (int i = 0; i < d.size(); i++) {
           Device s = d.get(i);
           r1.removeDevice(s);
           r2.addDevice(s);
           s.turnOn();
        }
    }
    
    public void coolRoom1() {
        Room Room1 = getRoom(1);
        for (int i = 0; i < Room1.getDevices().size(); i++){
            Device d = Room1.getDevices().get(i);
            if (d instanceof AC){
                d.turnOff();
            }
            if (d instanceof CeilingFan){
                d.turnOn();
            }
            if (d instanceof StandingFan){
                d.turnOn();
            }
        }
    }
    
    public void coolRoom2() {
        Room Room2 = getRoom(2);
        for (int i = 0; i < Room2.getDevices().size(); i++){
            Device d = Room2.getDevices().get(i);
            if (d instanceof AC){
                d.turnOn();
            }
            if (d instanceof CeilingFan){
                d.turnOff();
            }
            if (d instanceof StandingFan){
                d.turnOff();
            }
        }
    }
    
    public void coolRoom3() {
        Room Room3 = getRoom(3);
        for (int i = 0; i < Room3.getDevices().size(); i++){
            Device d = Room3.getDevices().get(i);
            if (d instanceof AC){
                d.turnOn();
            }
            if (d instanceof CeilingFan){
                d.turnOn();
            }
            if (d instanceof StandingFan){
                d.turnOff();
            }
        }
    }
    
    public void coolRoom4() {
        Room Room4 = getRoom(4);
        Room Room2 = getRoom(2);
        Room Room3 = getRoom(3);
        swapPortableDevices(Room2, Room4);
        swapPortableDevices(Room3, Room4);
        for (int i = 0; i < Room4.getDevices().size(); i++) {
            Device d = Room4.getDevices().get(i);
            if (d instanceof AC){
                d.turnOn();
            }
            if (d instanceof CeilingFan){
                d.turnOn();
            }
            if (d instanceof StandingFan){
                d.turnOn();
            }
        }
    }
    
    public void printStates() {
        for (int i = 1; i < 5; i++) {
            Room RoomI = getRoom(i);
            RoomI.printState();
        }
    }
    
        public static void main(String[] args){
        CoolingSimulation sim = new CoolingSimulation();
        sim.createRooms();
        sim.createDevices();
        sim.coolRoom1();
        sim.coolRoom2();
        sim.coolRoom3();
        sim.coolRoom4();
        sim.printStates();
    }
}