// 816032732 - Ethan Lee Chong

public final class StandingFan extends Fan implements PortableDevice {
    private int breeziness = 2;
    private int noisiness = 2;
    private int cools = 1;
    private String status;
    private static int counter = 1;
    private String ID;
    
    public String getID() {
        return ID;
    }
    
    public boolean isBreezy() {
        if (breeziness > 0 ) {
            return true;
        }
    return false;
    }
    
    public boolean isNoisy() {
        if (noisiness > 0) {
            return true;
        }
    return false;
    }
    
    public boolean isOn() {
        if (status == "On") {
            return true;
        }
    return false;
    }
    
    public void turnOn() {
        status = "On";
    }
    
    public void turnOff() {
        status = "Off";
    }
    
    public int coolsBy() {
        return cools;
    }
    
    public int getBreeziness() {
        return breeziness;
    }
    
    public int getNoisiness() {
        return noisiness;
    }
    
    public StandingFan() {
        super();
        ID = "SFAN" + counter;
        counter++;
    }
}