// 816032732 - Ethan Lee Chong
public interface Device {
    String getID();
    boolean isBreezy();
    boolean isNoisy();
    boolean isOn();
    void turnOn();
    void turnOff();
    int coolsBy();
    int getBreeziness();
    int getNoisiness();
}