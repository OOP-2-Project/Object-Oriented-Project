// 816032732 - Ethan Lee Chong

public abstract class Fan implements Device {
    protected int breeziness = 2;
    protected int noisiness;
    protected int cools;
    protected String status;
    protected static int counter = 1;
    protected String ID;
    
    public String getID() {
        return ID;
    }
    
    public boolean isBreezy(int breeziness) {
        if (breeziness > 0 ) {
            return true;
        }
    return false;
    }
    
    public boolean isNoisy(int noisiness) {
        if (noisiness > 0) {
            return true;
        }
    return false;
    }
    
    public boolean isOn(String status) {
        if (status == "On") {
            return true;
        }
    return false;
    }
    
    public void turnOn() {
        status = "On";
    }
    
    public void turnOff() {
        status = "Off";
    }
    
    public int coolsBy() {
        return cools;
    }
    
    public int getBreeziness() {
        return breeziness;
    }
    
    public int getNoisiness() {
        return noisiness;
    }
    
    public Fan() {
        this.breeziness = breeziness;
        this.noisiness = noisiness;
        this.cools = cools;
        this.status = "Off";
        this.ID = Integer.toString(counter);
        counter++;
    }
    
    public Fan(int noisiness) {
        this.breeziness = breeziness;
        this.noisiness = noisiness;
        this.cools = cools;
        this.status = "Off";
        this.ID = Integer.toString(counter);
        counter++;
    }
}