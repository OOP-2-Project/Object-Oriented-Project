// 816032732 - Ethan Lee Chong

public interface PortableDevice {
    
}
