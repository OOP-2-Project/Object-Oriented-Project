// 816032732 - Ethan Lee Chong

public class AC implements Device {
    private int breeziness = 0;
    private int noisiness = 0;
    private int cools = 5;
    private static int counter = 1;
    private String status;
    private String ID;
    
    public String getID() {
        return ID;
    }
    
    public boolean isBreezy() {
        if (breeziness > 0 ) {
            return true;
        }
    return false;
    }
    
    public boolean isNoisy() {
        if (noisiness > 0) {
            return true;
        }
    return false;
    }
    
    public boolean isOn() {
        if (status == "On") {
            return true;
        }
    return false;
    }
    
    public void turnOn() {
        status = "On";
    }
    
    public void turnOff() {
        status = "Off";
    }
    
    public int coolsBy() {
        return cools;
    }
    
    public int getBreeziness() {
        return breeziness;
    }
    
    public int getNoisiness() {
        return noisiness;
    }
    
    public AC() {
        this.breeziness = breeziness;
        this.noisiness = noisiness;
        this.cools = cools;
        this.status = "Off";
        ID = "AC" + counter;
        counter++;
    }
}