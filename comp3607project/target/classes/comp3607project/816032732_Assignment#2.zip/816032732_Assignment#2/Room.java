// 816032732 - Ethan Lee Chong

import java.util.ArrayList;

public class Room {
    private int startingTemperature;
    private ArrayList<Device> Devices;
    
    public Room(int startingTemperature) {
        this.startingTemperature = startingTemperature;
        this.Devices = new ArrayList<Device>();
    }
    
    public ArrayList<Device> getDevices() {
        return Devices;
    }
    
    public boolean addDevice(Device d) {
        if (!Devices.contains(d)) {
            Devices.add(d);
            return true;
        }
        return false;
    }
    
    public boolean removeDevice(Device d) {
        if (d instanceof PortableDevice) {
            return Devices.remove(d);
    }
        return false;
    }
    
    public int getTemperatureDrop() {
        int temperatureDrop = 0;
        for (int i = 0; i < Devices.size(); i++) {
            Device d = Devices.get(i);
            if (d.isOn() == true) {
                temperatureDrop += d.coolsBy();
            }
        }
        return temperatureDrop;
    }
    
    public int getTemperature() {
        int Temperature= startingTemperature - getTemperatureDrop();
        return Temperature;
    }
    
    public int getBreeziness() {
        int Breeziness = 0;
        for (int i = 0; i< Devices.size(); i++) {
            Device d = Devices.get(i);
            if (d.isOn() == true) {
                Breeziness += d.getBreeziness();
            }
        }
        return Breeziness;
    }
    
    public int getNoisiness() {
        int Noisiness = 0;
        for (int i = 0; i < Devices.size(); i++) {
            Device d = Devices.get(i);
            if (d.isOn() == true) {
                Noisiness += d.getNoisiness();
            }
        }
        return Noisiness;
    }
    
    public void printState() {
        System.out.println("Breeziness: " + getBreeziness());
        System.out.println("Noisiness: " + getNoisiness());
        System.out.println("Temperature: " + getTemperature());
    }
}